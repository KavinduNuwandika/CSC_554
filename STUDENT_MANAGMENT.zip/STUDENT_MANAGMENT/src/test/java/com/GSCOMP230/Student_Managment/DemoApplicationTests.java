package com.GSCOMP230.Student_Managment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = Application.class)  // Explicitly specifying the main application class
class DemoApplicationTests {

	@Test
	void contextLoads() {
	}
}
